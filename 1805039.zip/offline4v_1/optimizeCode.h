#ifndef OPTIMIZECODE_H

#include <bits/stdc++.h>
using namespace std;
void optimizeCode();

#endif // !OPTIMIZECODE_H