#ifndef GLOBALFUNCTIONS_H_
#define GLOBALFUNCTIONS_H_

#include "hashFunction.cpp"

int hashFunction();

#endif // !1
