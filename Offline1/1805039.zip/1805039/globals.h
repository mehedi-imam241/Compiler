#ifndef GLOBAL_H_
#define GLOBAL_H_

extern int totalBuckets;

#endif // !GLOBAL_H_
